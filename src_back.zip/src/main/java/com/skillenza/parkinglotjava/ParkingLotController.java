package com.skillenza.parkinglotjava;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class ParkingLotController {

	@Autowired
	private ParkingLotRepository parkingLotRepository;

	@GetMapping("/api/parkings")
	public List<ParkingLot> getAllParkingLots() {
		return parkingLotRepository.findAll();
	}

	@PostMapping("/api/parkings")
	public ResponseEntity createParkingLot(@Valid @RequestBody ParkingLot parkingLot) {
		try {
			ParkingLot savedParkingLot = parkingLotRepository.save(parkingLot);
			return ResponseEntity.ok(savedParkingLot);
		} catch (DataIntegrityViolationException constraintViolationException) {
			constraintViolationException.printStackTrace();
			return ResponseEntity.status(HttpStatus.CONFLICT).body("VEHICLE ALREADY PARKED");
		}
	}
}
